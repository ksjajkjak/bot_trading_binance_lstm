# Bot de Trading en Binance con LSTM y dos estrategias
