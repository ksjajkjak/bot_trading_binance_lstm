# Placeholder para enviar mensajes de Telegram
