
from binance_handler import BinanceHandler
from telegram_bot import send_telegram_message
from technical_analysis import TechnicalAnalysis
from tensorflow.keras.models import load_model
import numpy as np
import time

# Inicializar componentes
binance = BinanceHandler()
model = load_model("model_5m.h5")

def scalping_strategy(price, prediction, current_positions):
    try:
        candles = binance.get_klines(limit=60)
        ta = TechnicalAnalysis()
        engulfing = ta.check_engulfing(candles)
        bos = ta.check_break_of_structure(candles)
        pred_signal = "BUY" if prediction == "up" else "SELL"

        confirming_signals = 0
        if engulfing == pred_signal:
            confirming_signals += 1
        if bos == pred_signal:
            confirming_signals += 1

        if confirming_signals == 0:
            send_telegram_message("⚠️ Sin confirmación técnica - no operar en scalping")
            return
        elif confirming_signals == 1:
            send_telegram_message("✅ Una señal técnica confirma la predicción LSTM")
        else:
            send_telegram_message("✅✅ Máxima confirmación - todas las señales coinciden")

        if current_positions and current_positions != prediction:
            send_telegram_message("⚠️ Conflicto con posiciones existentes - no operar")
            return

        side = "BUY" if prediction == "up" else "SELL"
        entry_price = price
        tp, sl = ta.calculate_dynamic_tp_sl(candles, side, entry_price)
        cantidad_optima = binance.calcular_cantidad_optima(price)

        if cantidad_optima <= 0:
            send_telegram_message("⚠️ No se pudo calcular cantidad válida para scalping - saldo insuficiente")
            return

        order = binance.place_market_order(side, cantidad_optima)
        if not order:
            send_telegram_message("❌ No se pudo ejecutar la orden de mercado para scalping")
            return

        binance.set_tp_sl(side, tp, sl)
        send_telegram_message(f"⚡ Scalping {side} ejecutado a {entry_price:.4f} TP: {tp:.4f}, SL: {sl:.4f} Cantidad: {cantidad_optima}")
    except Exception as e:
        send_telegram_message(f"❌ Error en scalping strategy: {str(e)}")

def swing_strategy(price, prediction, current_positions):
    try:
        candles = binance.get_klines(limit=60)
        ta = TechnicalAnalysis()
        engulfing = ta.check_engulfing(candles)
        bos = ta.check_break_of_structure(candles)
        pred_signal = "BUY" if prediction == "up" else "SELL"

        confirming_signals = 0
        if engulfing == pred_signal:
            confirming_signals += 1
        if bos == pred_signal:
            confirming_signals += 1

        if confirming_signals == 0:
            send_telegram_message("⚠️ Sin señales confirmatorias en swing - no operar")
            return
        elif confirming_signals == 1:
            send_telegram_message("ℹ️ Una señal confirmatoria en swing - operando con precaución")
        else:
            send_telegram_message("✅ Todas las señales confirmatorias en swing")

        if current_positions and current_positions != prediction:
            send_telegram_message("⚠️ Conflicto con posiciones existentes - no operar")
            return

        side = "BUY" if prediction == "up" else "SELL"
        entry_price = price
        tp, sl = ta.calculate_dynamic_tp_sl(candles, side, entry_price)
        cantidad_optima = binance.calcular_cantidad_optima(price)

        if cantidad_optima <= 0:
            send_telegram_message("⚠️ No se pudo calcular cantidad válida para swing trading - saldo insuficiente")
            return

        order = binance.place_limit_order(side, cantidad_optima, entry_price)
        if not order:
            send_telegram_message("❌ No se pudo ejecutar la orden límite para swing trading")
            return

        time.sleep(2)
        binance.set_tp_sl(side, tp, sl)
        send_telegram_message(f"📈 Swing {side} en {entry_price:.4f} TP: {tp:.4f}, SL: {sl:.4f} Cantidad: {cantidad_optima}")
    except Exception as e:
        send_telegram_message(f"❌ Error en swing strategy: {str(e)}")
